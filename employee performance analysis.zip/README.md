# Employees_performance_analysis
The following insights are expected from this project. 1. Department wise performances 2. Top 3 Important Factors effecting employee performance 3. A trained model which can predict the employee performance based on factors as inputs. 4. Recommendations to improve the employee performance based on insights from the analysis. 
